import $ from 'jquery';

require('datatables.net-bs')
require('datatables.net-bs4/js/dataTables.bootstrap4.js')
require('datatables.net-bs4/css/dataTables.bootstrap4.css')
require('datatables.net-buttons')
require('datatables.net-buttons-bs')
require('datatables.net-responsive')
require('datatables.net-responsive-bs')
require('datatables.net-responsive-bs/css/responsive.bootstrap.css')
require('datatables.net-buttons/js/buttons.colVis.js') // Column visibility
require('datatables.net-buttons/js/buttons.html5.js') // HTML 5 file export
require('datatables.net-buttons/js/buttons.flash.js') // Flash file export
require('datatables.net-buttons/js/buttons.print.js') // Print view button
require('datatables.net-keytable');
require('datatables.net-keytable-bs/css/keyTable.bootstrap.css')
require('jszip/dist/jszip.js');
require('pdfmake/build/pdfmake.js');
require('pdfmake/build/vfs_fonts.js');

const dtOptions = {
    pageLength: 100,
    paging: true, // Table pagination
    ordering: true, // Column ordering
    info: true, // Bottom left status text
    destroy: true,
    responsive: false,
    oLanguage: {
        sSearch: '<em class="fa fa-search"></em>',
        sLengthMenu: '_MENU_ на страница', // DataTables has a build in number formatter (fnFormatNumber) which is used to format large numbers that are used in the table information. By default a comma is used, but this can be trivially changed to any character you wish with this parameter.
        sInfo: "Показва _START_ - _END_ от общо _TOTAL_", // This string gives information to the end user about the information that is current on display on the page. The _START_, _END_ and _TOTAL_ variables are all dynamically replaced as the table display updates, and can be freely moved or removed as the language requirements change.
        sEmptyTable: "Няма налични данни", // This string is shown in preference to sZeroRecords when the table is empty of data (regardless of filtering). Note that this is an optional parameter - if it is not given, the value of sZeroRecords will be used instead (either the default or given value).
        sInfoEmpty: "Няма данни за показване", // Display information string for when the table is empty. Typically the format of this string should match sInfo.
        sInfoFiltered: "(филтрирани от _MAX_ записа)", // When a user filters the information in a table, this string is appended to the information (sInfo) to give an idea of how strong the filtering is. The variable _MAX_ is dynamically updated.
        sZeroRecords: "Няма данни за показване", // Text shown inside the table records when the is no information to be displayed after filtering. sEmptyTable is shown when there is simply no information in the table at all (regardless of filtering).
        oPaginate: {
            sNext: '<em class="fa fa-caret-right"></em>',
            sPrevious: '<em class="fa fa-caret-left"></em>'
        }
    }
}

export const setDatatableConfig = (ref, options = {}) => {
    if (!$.fn.dataTable.isDataTable(ref)) 
    $(ref).DataTable({
        ...dtOptions,
        ...options
    });
}
