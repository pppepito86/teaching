export function gradientColor(ratio) {
    return ratio === 1 ? 'score100' :
      ratio > 0.9 ? 'score95' :
        ratio > 0.8 ? 'score85' :
          ratio > 0.7 ? 'score75' :
            ratio > 0.6 ? 'score65' :
              ratio > 0.5 ? 'score55' :
                ratio > 0.4 ? 'score45' :
                  ratio > 0.3 ? 'score35' :
                    ratio > 0.2 ? 'score25' :
                      ratio > 0.1 ? 'score15' :
                        ratio > 0 ? 'score5' :
                          ratio === 0 ? 'score0' :
                            'noscore';
}

export function getColor(ratio) {
  return ratio === 1 ? '#4E9A05' :
    ratio > 0.9 ? '#639B04' :
      ratio > 0.8 ? '#789C03' :
        ratio > 0.7 ? '#8E9D02' :
          ratio > 0.6 ? '#A39E01' :
            ratio > 0.5 ? '#B99F00' :
              ratio > 0.4 ? '#C89100' :
                ratio > 0.3 ? '#D17400' :
                  ratio > 0.2 ? '#D95700' :
                    ratio > 0.1 ? '#E23A00' :
                      ratio > 0 ? '#EB1D00' :
                        ratio === 0 ? '#F40000' :
                          '#FFFFFF';
}