import React, { Suspense, lazy } from 'react';
import { withRouter, Switch, Route, Redirect } from 'react-router-dom';
import { TransitionGroup, CSSTransition } from 'react-transition-group';

/* loader component for Suspense*/
import PageLoader from './components/Common/PageLoader';

import UserBase from './components/Layout/User/UserBase';
import AdminBase from './components/Layout/Admin/AdminBase';
import BasePage from './components/Layout/BasePage';
import { useAuth } from './AuthContext';
import AuthorBase from './components/Layout/Author/AuthorBase';
import SpectatorBase from './components/Layout/Spectator/SpectatorBase';

/* Used to render a lazy component with react-router */
const waitFor = Tag => props => <Tag {...props}/>;

const SpectatorContestStanding = lazy(() => import('./components/Competition/ContestStanding'));

const Routes = ({ location }) => {
    <SpectatorBase>
        <TransitionGroup>
            <CSSTransition key={currentKey} timeout={timeout} classNames={animationName} exit={false}>
                <div>
                    <Suspense fallback={<PageLoader/>}>
                        <Switch location={location}>
                            <Route path="/standing/:cname" component={waitFor(SpectatorContestStanding)}/>
                            <Route path="/standing" component={waitFor(SpectatorContestStanding)}/>

                            <Redirect to="/standing" />
                        </Switch>
                    </Suspense>
                </div>
            </CSSTransition>
        </TransitionGroup>
    </SpectatorBase>


    return <Redirect to='/login'/>;
}

export default withRouter(Routes);
