import React from 'react';
import { Link } from 'react-router-dom';
import { Input, Button } from 'reactstrap';

import SidebarLogo from '../Layout/SidebarLogo.js';
import { useAuth } from '../../AuthContext.js';
import { useState } from 'react';
import { useTranslation, withTranslation } from 'react-i18next';

function Login() {

    const { t, i18n } = useTranslation();

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);

    const login = useAuth().login;

    const changeLanguage = (e, lng) => {
        e.preventDefault();
        localStorage.setItem('lang', lng); 
        i18n.changeLanguage(lng);
    }
  
    const handleLogin = async (e) => {
        e.preventDefault();
        await login(username, password, true);
    }

    return (
        <div className="block-center mt-4 wd-xl">
            <div className="card card-flat">
                <div className="card-header text-center bg-info">
                    <div className="navbar-brand text-wrap">
                        {/* XII Международен Есенен Турнир по Информатика */}
                        {/* XII International Autumn Tournament in Informatics */}
                    	{/* Софийски турнир по информатика */}
                    	{/* Второ контролно */}
                        {/* Национална олимпиада по информатика, трети кръг */}
                        {t('login.contest_name')}
                    </div>
                </div>
                <div style={{marginTop: '15px'}}>
                    <SidebarLogo />
                </div>
                {process.env.REACT_APP_ALLOW_TRANSLATION === 'true' &&
                <div className="text-center">
                    <a onClick={(e) => changeLanguage(e, "bg")} className={'mr-1 badge '+(t('lang') === 'bg'?'badge-primary':'badge-white')} href="">bg</a>
                    <a onClick={(e) => changeLanguage(e, "en")} className={'mr-1 badge '+(t('lang') === 'en'?'badge-primary':'badge-white')} href="">en</a>
                </div>
                }

                <div className="card-body">
                    <form className="mb-3" name="formLogin">
                        <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="text"
                                    name="username"
                                    className="border-right-0"
                                    placeholder={t('login.username')}
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    data-validate='["required"]'/>
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-user"></em>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type={showPassword?"text":"password"}
                                    id="id-password"
                                    name="password"
                                    className="border-right-0"
                                    placeholder={t('login.password')}

                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    data-validate='["required"]'
                                />
                                <div onClick={() => setShowPassword(show => !show)} className="input-group-append">
                                    <span toggle="#id-password" className="input-group-text text-muted bg-transparent border-left-0">
                                        <em style={{cursor: 'pointer'}} className="fa fa-fw fa-eye field-icon toggle-password"></em>
                                    </span>
                                </div>
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-lock"></em>
                                    </span>
                                </div>
                                <span className="invalid-feedback">Field is required</span>
                            </div>
                        </div>
                        <div className="clearfix">
                            <div className="float-right">
                                {/* <Link to="recover" className="text-muted">Забравена парола?</Link> */}
                            </div>
                        </div>
                        {/* <div className="float-right">
                            <a href="/api/practice" target="_blank" rel="noopener noreferrer" className="text-muted">Коя ми е паролата?</a>
                        </div> */}
                        <Button type="submit" onClick={e => handleLogin(e)} className="btn btn-block btn-info mt-3 bg-info">{t('login.log_in')}</Button>
                    </form>
                    {process.env.REACT_APP_ALLOW_REGISTER === 'true' && <p className="pt-3 text-center">{t('login.need_to_signup')}</p>}
                    {process.env.REACT_APP_ALLOW_REGISTER === 'true' && <Link to="register" className="btn btn-block btn-secondary">{t('login.registration')}</Link>}
                </div>
            </div>
            <div className="p-3 text-center">
                <span>&copy; 2016-{new Date().getFullYear()} - {t('footer.made_with')} <span style={{color: 'rgb(240, 80, 80)'}}>❤</span> {t('footer.for_bulgarian_informatics')} в <a target="_blank" href="https://olimpiici.com">школа "Олимпийци"</a>.</span>
            </div>
            </div>
    );
}

export default withTranslation()(Login);
