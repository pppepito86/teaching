import React from 'react';
import { Link } from 'react-router-dom';
import { Input, Button, Form, FormGroup, Col, Row, Label } from 'reactstrap';
import Countdown from 'react-countdown';

import SidebarLogo from '../Layout/SidebarLogo.js';
import { useAuth } from '../../AuthContext.js';
import { useState } from 'react';
import { now } from 'moment';
import { timeDay } from 'd3';

const Game = () => {
    const [state, setState] = useState(0);

    const [level, setLevel] = useState("easy");
    const [time, setTime] = useState(0);
    const [borderColor, setBorderColor] = useState('none');
    const [a, setA] = useState("");
    const [b, setB] = useState("");
    const [correct, setCorrect] = useState(0);
    const [wrong, setWrong] = useState(0);
    const [c, setC] = useState("");
    const [value, setValue] = useState(10);

    const getTime = () => {
        if (level === "easy") return value/5.0+1;
        else if (level === "medium") return (value/5.0+value/10.0)/2+0.5;
        else return value/10.0;
    }
  
    const answer = async (e) => {
        if (e) e.preventDefault();

        if (state === 1) {
            if (c === ''+(a*b)) setCorrect(c => c+1);
            else setWrong(w => w+1);
            if (c === ''+(a*b)) setBorderColor('green');
            else setBorderColor('red');
            setState(2);
        } else if (state === 0 || state === 2) {
            setA(Math.floor(Math.random() * value) + 1);
            setB(Math.floor(Math.random() * value) + 1);
            setC("");
            setBorderColor('none');

            setState(1);
            setTime(now() + getTime()*1000);
        }
    }

    const keyPressed = (event) => {
        if (event.key === "Enter") {
            console.log("press");
            answer();
        }
    }

    const renderer = ({seconds, completed }) => {
        if (completed) {
            return 'Времете изтече';
        } else {
            return <span>{`${seconds} сек.`}</span>;
        }
    };

    return (
        <div className="block-center mt-4 wd-xl">
            <div className="card card-flat">
                <div className="card-header text-center bg-info">
                    <div className="navbar-brand" style={{color: 'white'}}>
                        PESHO.ORG
                    </div>
                </div>
                {state !== 0 &&
                        <Row form>
                            <Col sm={6}>
                                <FormGroup>
                                    <Label>Верни</Label>
                                    <Input style={{backgroundColor: 'green', color:'white'}} value={correct} disabled type="text" />
                                </FormGroup>
                            </Col>
                            <Col sm={6}>
                                <FormGroup>
                                    <Label>Грешни</Label>
                                    <Input style={{backgroundColor: 'red', color:'white'}} value={wrong} disabled type="text" />
                                </FormGroup>
                            </Col>
                        </Row>}
                {/* <SidebarLogo/> */}
                <div className="card-body">
                    <div id="timer" style={{ color: '#b8c7ce', textAlign: 'center', fontSize: '30px' }}>{'Време '}
                    {state !== 1 && (getTime().toFixed(1) + ' сек.')}
                    {state === 1 &&
                        <Countdown 
                        onComplete={() => answer()}
                        date={time} renderer={renderer}/>}
                    </div>
                    <form className="mb-3" name="formLogin">
                        {state === 0 &&
                            <FormGroup>
                                <Label>Ниво</Label>
                                <Input
                                onChange={(e) => setLevel(e.target.value)}
                                value={level}
                                type="select" name="select">
                                    <option value="easy">Лесно</option>
                                    <option value="medium">Средно</option>
                                    <option value="hard">Трудно</option>
                                </Input>
                                <br />
                                <Label>Максимално число</Label>
                                <Input value={value} onChange={(e) => setValue(e.target.value)} type="text" />
                            </FormGroup>
                        }
                        {state !== 0 &&
                        <Row form>
                            <Col sm={6}>
                                <FormGroup>
                                    <Label>A</Label>
                                    <Input value={a} disabled type="text" />
                                </FormGroup>
                            </Col>
                            <Col sm={6}>
                                <FormGroup>
                                    <Label>B</Label>
                                    <Input value={b} disabled type="text" />
                                </FormGroup>
                            </Col>
                        </Row>}
                        {state === 1 &&
                        <FormGroup>
                            <Label>AxB</Label>
                            <Input
                            onKeyPress={keyPressed}
                            value={c}
                            onChange={(e) => setC(e.target.value)}
                            autoFocus
                            type="text" />
                        </FormGroup>
                        }
                        {state === 2 &&
                        <FormGroup>
                            <Label>AxB = {a*b}</Label>
                            <Input
                            style={{backgroundColor: borderColor, color: 'white'}}
                            value={c}
                            type="text" disabled />
                        </FormGroup>
                        }

                        {state===1 &&<Button
                        type="submit" onClick={e => answer(e)} className="btn btn-block btn-info mt-3 bg-info">
                            {state===0?'ЗАПОЧНИ':state===1?'ОТГОВОРИ':'СЛЕДВАЩ'}</Button>}
                        {state!==1 &&<Button
                        autoFocus
                        type="submit" onClick={e => answer(e)} className="btn btn-block btn-info mt-3 bg-info">
                            {state===0?'ЗАПОЧНИ':state===1?'ОТГОВОРИ':'СЛЕДВАЩ'}</Button>}
                    </form>
                </div>
            </div>
            <div className="p-3 text-center">
                <span>&copy; 2016-{2020} - Направено с <span style={{color: 'rgb(240, 80, 80)'}}>❤</span> от Пешо и Марин в <a href="http://olimpiici.com/">школа Олимпийци</a>.</span>
            </div>
        </div>
    );
}

export default Game;
