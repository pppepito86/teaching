import React from 'react';
import { Redirect, useHistory } from 'react-router-dom';
import { Input, Button, FormGroup, Label } from 'reactstrap';

import SidebarLogo from '../Layout/SidebarLogo.js';
import { useAuth } from '../../AuthContext.js';
import { useState } from 'react';
import { sendPostRequest } from '../../rest'
import swal from 'sweetalert';

import { useTranslation, withTranslation } from 'react-i18next';

function Register() {

    const { t, i18n } = useTranslation();

    const history = useHistory();

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [password2, setPassword2] = useState("");
    const [contest, setContest] = useState("T");
    const [name, setName] = useState("");
    const [country, setCountry] = useState("");

    const login = useAuth().login;
  
    const handleRegister = async (e) => {
        e.preventDefault();

        if (contest === "") swal('Error', 'You hava to choose contest!', 'error');
        if (username.length < 3) swal('Error', 'Username should be at least 3 symbols!', 'error');
        if (username.length > 20) swal('Error', 'Username should be not more than 20 symbols!', 'error');
        if (password.length < 3) swal('Error', 'Password should be at least 3 symbols!', 'error');
        if (password.length > 20) swal('Error', 'Password should be not more than 20 symbols!', 'error');
        if (password !== password2) swal('Error', 'Passwords should match!', 'error');

        const formData = new FormData();
        formData.append('username', username);
        formData.append('password', password);
        formData.append('contest', contest);
        formData.append('name', name);
        formData.append('country', country);

        sendPostRequest('me/register', formData).then((response) => {
            if (response.status === 200) {
                swal('Success', 'User created!', 'success');
                history.push('/login');
            } else {
                swal('Error', 'User not created!', 'error');
            }
        });
    }

    const year = new Date().getFullYear();

    return (
        <div className="block-center mt-4 wd-xl">
            <div className="card card-flat">
                <div className="card-header text-center bg-info">
                    <div className="navbar-brand text-wrap">
                        {/* XII Международен Есенен Турнир по Информатика */}
                        {t('login.contest_name')}
                    	{/* Софийски турнир по информатика */}
                    	{/* Второ контролно */}
                        {/* Национална олимпиада по информатика, трети кръг */}
                    </div>
                </div>
                <div style={{marginTop: '15px'}}>
                    <SidebarLogo />
                </div>
                <div className="card-body">
                    <form className="mb-3" name="formLogin">
                        <FormGroup>
                            <select onChange={(e) => setContest(e.target.value)} value={contest} className="form-control">
                                {/* <option value="" disabled>Select contest</option> */}
                                <option value="T">E&I</option>
                                {/* <option value="B1">Junior</option> */}
                            </select>
                        </FormGroup>
                        <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="text"
                                    name="username"
                                    className="border-right-0"
                                    placeholder="Username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    data-validate='["required"]'/>
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-user"></em>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="password"
                                    id="id-password"
                                    name="password"
                                    className="border-right-0"
                                    placeholder="Password"
                                    
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    data-validate='["required"]'
                                />
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-lock"></em>
                                    </span>
                                </div>
                                <span className="invalid-feedback">Field is required</span>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="password"
                                    id="id-password"
                                    name="password"
                                    className="border-right-0"
                                    placeholder="Repeat password"
                                    
                                    value={password2}
                                    onChange={(e) => setPassword2(e.target.value)}
                                    data-validate='["required"]'
                                />
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-lock"></em>
                                    </span>
                                </div>
                                <span className="invalid-feedback">Field is required</span>
                            </div>
                        </div>
                        {/* <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="text"
                                    name="name"
                                    className="border-right-0"
                                    placeholder="Your name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    data-validate='["required"]'/>
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-user"></em>
                                    </span>
                                </div>
                            </div>
                        </div> */}
                        {/* <div className="form-group">
                            <div className="input-group with-focus">
                                <Input type="text"
                                    name="country"
                                    className="border-right-0"
                                    placeholder="Country"
                                    value={country}
                                    onChange={(e) => setCountry(e.target.value)}
                                    data-validate='["required"]'/>
                                <div className="input-group-append">
                                    <span className="input-group-text text-muted bg-transparent border-left-0">
                                        <em className="fa fa-flag"></em>
                                    </span>
                                </div>
                            </div>
                        </div> */}
 
                        <div className="clearfix">
                            <div className="float-right">
                                {/* <Link to="recover" className="text-muted">Забравена парола?</Link> */}
                            </div>
                        </div>
                        <Button type="submit" onClick={e => handleRegister(e)} className="btn btn-block btn-info mt-3 bg-info">REGISTER</Button>
                    </form>
                </div>
            </div>
            <div className="p-3 text-center">
                <span>&copy; 2016-{year} - Made with <span style={{color: 'rgb(240, 80, 80)'}}>❤</span> for the competitive programming.</span>
                {/* <span>&copy; 2016-{year} - с <span style={{color: 'rgb(240, 80, 80)'}}>❤</span> за българската състезателна информатика.</span> */}
            </div>
            </div>
    );
}

export default withTranslation()(Register);
