import React from 'react';

import Header from '../Header'
import SpectatorSidebar from './SpectatorSidebar'
import Footer from '../Footer'
import { ContestProvider } from '../../../ContestContext';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SpectatorBase = props => (
    <ContestProvider>
        <ToastContainer />
        <div className="wrapper">
            <Header />

            <SpectatorSidebar />

            <section className="section-container">
                { props.children }
            </section>

            <Footer />
        </div>
    </ContestProvider>
)

export default SpectatorBase;
