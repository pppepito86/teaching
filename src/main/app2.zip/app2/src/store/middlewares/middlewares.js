import settings from './settings.middleware.js'
import themes from './themes.middleware.js';

export default [
    settings,
    themes
]